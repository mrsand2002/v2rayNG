package com.v2ray.ang.ui.main

import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.net.Uri
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import kotlin.math.max

private val Navy = Color(0xFF0A1120)
private val Cyan = Color(0xFF38D9E6)
private val Dim = Color(0xFF9AAFC6)
private val Panel = Color(0xFF16263A)

private enum class ToastKind { Info, Success, Error }
private data class ToastNotice(val text: String, val kind: ToastKind, val id: Int)

private fun readableBytes(bytes: Long): String {
    val b = bytes.coerceAtLeast(0).toDouble()
    return when {
        b >= 1024.0 * 1024 * 1024 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
        b >= 1024.0 * 1024 -> "%.1f MB".format(b / (1024.0 * 1024))
        b >= 1024 -> "%.0f KB".format(b / 1024)
        else -> "${bytes.coerceAtLeast(0)} B"
    }
}
private fun readableDuration(milliseconds: Long): String {
    val s = milliseconds.coerceAtLeast(0) / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
}

/** Customer-only experience. VPN profile/server/TLS/SNI are centrally assigned. */
@Composable
fun ZentManagedScreen(
    isRunning: Boolean,
    hasLocalProfile: Boolean,
    onStartVpn: () -> Unit,
    onStopVpn: () -> Unit,
    onApplyProfile: suspend (String) -> Boolean,
    onClearProfile: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vault = remember(context) { ZentSessionVault(context) }
    val prefs = remember(context) { context.getSharedPreferences("zent_preferences", Context.MODE_PRIVATE) }
    var token by remember { mutableStateOf(vault.read().orEmpty()) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var account by remember { mutableStateOf<ZentAccount?>(null) }
    var busy by remember { mutableStateOf(false) }
    var profileReady by remember { mutableStateOf(hasLocalProfile) }
    var appliedMarker by remember { mutableStateOf(prefs.getString("applied_marker", "").orEmpty()) }
    var toast by remember { mutableStateOf<ToastNotice?>(null) }
    var noticeId by remember { mutableIntStateOf(0) }
    var connecting by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var page by remember { mutableStateOf("Home") }
    var showLogoutConfirmation by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var versionMessage by remember { mutableStateOf("") }
    var updateInfo by remember { mutableStateOf<ZentUpdateInfo?>(null) }
    var checkingVersion by remember { mutableStateOf(false) }

    // Session stats: Android's app-UID traffic, not 3X-UI account-wide usage.
    var rxSpeed by remember { mutableLongStateOf(0L) }
    var txSpeed by remember { mutableLongStateOf(0L) }
    var sessionRx by remember { mutableLongStateOf(0L) }
    var sessionTx by remember { mutableLongStateOf(0L) }
    var uptimeMs by remember { mutableLongStateOf(0L) }
    var statsAvailable by remember { mutableStateOf(true) }

    fun notify(text: String, kind: ToastKind = ToastKind.Info) {
        noticeId += 1
        toast = ToastNotice(text, kind, noticeId)
    }
    LaunchedEffect(toast?.id) {
        val current = toast ?: return@LaunchedEffect
        delay(if (current.kind == ToastKind.Error) 6500 else 3200)
        if (toast?.id == current.id) toast = null
    }
    LaunchedEffect(Unit) { prefs.edit().remove("custom_sni").apply() }
    LaunchedEffect(isRunning) {
        if (isRunning) {
            connecting = false
            notify("VPN service active", ToastKind.Success)
            val startedAt = SystemClock.elapsedRealtime()
            var previousAt = startedAt
            var previousRx = TrafficStats.getUidRxBytes(context.applicationInfo.uid)
            var previousTx = TrafficStats.getUidTxBytes(context.applicationInfo.uid)
            statsAvailable = previousRx >= 0 && previousTx >= 0
            sessionRx = 0
            sessionTx = 0
            while (isActive) {
                delay(2000)
                val now = SystemClock.elapsedRealtime()
                uptimeMs = now - startedAt
                if (!statsAvailable) continue
                val newRx = TrafficStats.getUidRxBytes(context.applicationInfo.uid)
                val newTx = TrafficStats.getUidTxBytes(context.applicationInfo.uid)
                if (newRx < 0 || newTx < 0) { statsAvailable = false; continue }
                val elapsed = (now - previousAt).coerceAtLeast(1)
                val rx = max(0, newRx - previousRx)
                val tx = max(0, newTx - previousTx)
                rxSpeed = rx * 1000 / elapsed
                txSpeed = tx * 1000 / elapsed
                sessionRx += rx
                sessionTx += tx
                previousRx = newRx
                previousTx = newTx
                previousAt = now
            }
        } else {
            rxSpeed = 0
            txSpeed = 0
            uptimeMs = 0
        }
    }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(12000)
            if (connecting && !isRunning) {
                connecting = false
                notify("VPN did not start. Check the profile or VPN permission.", ToastKind.Error)
            }
        }
    }

    suspend fun syncProfile(authToken: String, force: Boolean = false) {
        if (busy) return
        busy = true
        try {
            val fetched = ZentApi.me(authToken)
            if (!fetched.active) throw IllegalStateException("Account inactive or expired")
            account = fetched
            val newUri = fetched.vlessUri
            if (newUri.isNullOrBlank()) {
                profileReady = false
                notify("No VPN server assigned to this account", ToastKind.Error)
                return
            }
            val marker = "zent-managed-v2:${fetched.username}:${fetched.revision}"
            if (force || !profileReady || marker != appliedMarker) {
                val reconnect = isRunning
                if (reconnect) onStopVpn()
                if (reconnect) delay(1800)
                if (!onApplyProfile(newUri)) {
                    throw IllegalStateException("Unable to install your assigned VPN profile")
                }
                prefs.edit().putString("applied_marker", marker).apply()
                appliedMarker = marker
                profileReady = true
                notify("VPN configuration updated", ToastKind.Success)
                if (reconnect) {
                    delay(900)
                    connecting = true
                    onStartVpn()
                }
            } else profileReady = true
        } catch (ex: Exception) {
            val err = ex.message ?: "Management server unavailable"
            notify(err.take(120), ToastKind.Error)
            if (err.contains("Login required", true) || err.contains("account expired", true)) {
                if (isRunning) onStopVpn()
                onClearProfile()
                vault.clear()
                token = ""
                profileReady = false
                account = null
            }
        } finally { busy = false }
    }

    LaunchedEffect(token) {
        if (token.isNotBlank()) syncProfile(token)
    }
    LaunchedEffect(token) {
        if (token.isNotBlank()) while (isActive) {
            delay(120_000)
            syncProfile(token)
        }
    }
    LaunchedEffect(token) {
        if (token.isNotBlank()) {
            val info = runCatching { ZentVersionCheck.latest() }.getOrNull()
            if (info != null && info.isNewer) {
                updateInfo = info
                notify("New Zent Plus update available", ToastKind.Info)
            }
        }
    }

    if (showLogoutConfirmation) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmation = false },
            title = { Text("Sign out of Zent Plus?") },
            text = { Text("You'll need to sign in again to use your account.") },
            confirmButton = { TextButton(onClick = {
                showLogoutConfirmation = false
                scope.launch {
                    busy = true
                    if (isRunning) onStopVpn()
                    try { ZentApi.logout(token) } catch (_: Exception) { }
                    onClearProfile()
                    vault.clear()
                    prefs.edit().remove("applied_marker").apply()
                    appliedMarker = ""
                    profileReady = false
                    token = ""
                    account = null
                    page = "Home"
                    drawerState.close()
                    busy = false
                }
            }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { showLogoutConfirmation = false }) { Text("Cancel") } }
        )
    }
    if (showAbout) {
        val version = remember(context) {
            runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Unknown" }
                .getOrDefault("Unknown")
        }
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Zent Plus", color = Cyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Secure. Simple. Connected.")
                    Text("Version  $version")
                    Text("Developer  Tharusha Sandeepa")
                    Text("Includes open-source Xray and v2rayNG components under their respective licenses.")
                    TextButton(onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://github.com/2dust/v2rayNG/blob/master/LICENSE")))
                    }) { Text("Open-source licenses") }
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") } }
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(Navy).windowInsetsPadding(WindowInsets.safeDrawing)) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = token.isNotBlank(),
                drawerContent = {
                    ModalDrawerSheet(drawerContainerColor = Panel, modifier = Modifier.width(290.dp)) {
                        Spacer(Modifier.height(30.dp))
                        Text("ZENT+", color = Cyan, fontWeight = FontWeight.Black, fontSize = 30.sp,
                            modifier = Modifier.padding(horizontal = 24.dp))
                        Text(account?.username ?: "Customer", color = Color.White,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
                        Text(if(account?.active == true) "Account active" else "Account status unavailable", color = Dim,
                            modifier = Modifier.padding(horizontal = 24.dp))
                        HorizontalDivider(modifier = Modifier.padding(vertical = 18.dp))
                        listOf("My Profile", "Data Usage", "Settings", "About Zent Plus").forEach { item ->
                            NavigationDrawerItem(
                                label = { Text(item) },
                                selected = page == item,
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    if (item == "About Zent Plus") showAbout = true else page = item
                                }, modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            scope.launch { drawerState.close() }
                            showLogoutConfirmation = true
                        }, modifier = Modifier.padding(20.dp)) { Text("Sign out", color = Color(0xFFFF9292)) }
                    }
                }
            ) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (token.isNotBlank()) {
                            Text("☰", color = Color.White, fontSize = 29.sp,
                                modifier = Modifier.clickable { scope.launch { drawerState.open() } }.padding(end = 18.dp))
                        }
                        Text("ZENT+", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Cyan)
                        Spacer(Modifier.weight(1f))
                        if (updateInfo != null) {
                            TextButton(onClick = {
                                val link = updateInfo?.url ?: return@TextButton
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }) { Text("Update") }
                        }
                    }
                    if (token.isBlank()) {
                        Spacer(Modifier.height(40.dp))
                        Text("Customer Sign In", color = Color.White, fontSize = 23.sp)
                        OutlinedTextField(username, { username = it }, label = { Text("Username") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(password, { password = it }, label = { Text("Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val session = ZentApi.login(username.trim(), password)
                                    vault.save(session)
                                    password = ""
                                    token = session
                                    notify("Signed in successfully", ToastKind.Success)
                                } catch (ex: Exception) {
                                    notify(ex.message ?: "Sign-in failed", ToastKind.Error)
                                } finally { busy = false }
                            }
                        }, enabled = !busy && username.isNotBlank() && password.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()) { Text("SIGN IN") }
                    } else when (page) {
                        "Home" -> {
                            Text("YOUR CONNECTION. SIMPLIFIED.", color = Dim, fontSize = 12.sp)
                            Spacer(Modifier.height(45.dp))
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(when {
                                    isRunning -> "VPN SERVICE ACTIVE"
                                    connecting -> "CONNECTING..."
                                    else -> "DISCONNECTED"
                                }, color = if(isRunning) Cyan else Color.White, fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp)
                                Button(onClick = {
                                    when {
                                        isRunning -> { onStopVpn(); notify("VPN disconnected") }
                                        account?.active != true -> notify("Account not active", ToastKind.Error)
                                        !profileReady || !hasLocalProfile -> {
                                            notify("Fetching your assigned VPN profile")
                                            scope.launch { syncProfile(token, true) }
                                        }
                                        else -> {
                                            connecting = true
                                            notify("Connecting… approve VPN permission if requested")
                                            try { onStartVpn() } catch (ex: Exception) {
                                                connecting = false
                                                notify(ex.message ?: "Unable to start VPN", ToastKind.Error)
                                            }
                                        }
                                    }
                                }, modifier = Modifier.size(186.dp), shape = CircleShape, enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)) {
                                    Text(if(isRunning) "DISCONNECT" else "CONNECT", fontWeight = FontWeight.Black, fontSize = 17.sp)
                                }
                                Text(if (profileReady) "Server managed by administrator" else "No VPN profile assigned",
                                    color = Dim)
                            }
                            Spacer(Modifier.height(15.dp))
                            // UID counters are estimates for this device, not 3X-UI lifetime data.
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("Download", if (statsAvailable) "${readableBytes(rxSpeed)}/s" else "Unavailable", Modifier.weight(1f))
                                StatCard("Upload", if (statsAvailable) "${readableBytes(txSpeed)}/s" else "Unavailable", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("Session", readableDuration(uptimeMs), Modifier.weight(1f))
                                StatCard("Session traffic", if (statsAvailable) readableBytes(sessionRx + sessionTx) else "Unavailable", Modifier.weight(1f))
                            }
                        }
                        "My Profile" -> {
                            PageHeader("My Profile") { page = "Home" }
                            InfoCard("Username", account?.username ?: "—")
                            InfoCard("Subscription", if(account?.active == true) "Active" else "Unavailable")
                            InfoCard("Expires", account?.expirySeconds?.let {
                                DateFormat.getDateInstance().format(Date(it * 1000))
                            } ?: "No expiry set")
                            InfoCard("Data allowance", "Unlimited")
                        }
                        "Data Usage" -> {
                            PageHeader("Data Usage") { page = "Home" }
                            InfoCard("Data allowance", "Unlimited ∞")
                            InfoCard("This VPN session — Download", if (statsAvailable) readableBytes(sessionRx) else "Unavailable")
                            InfoCard("This VPN session — Upload", if (statsAvailable) readableBytes(sessionTx) else "Unavailable")
                            InfoCard("This VPN session — Total", if (statsAvailable) readableBytes(sessionRx + sessionTx) else "Unavailable")
                            Text("These are approximate traffic counters for this device and session. Account-wide usage from 3X-UI is not connected yet.",
                                color = Dim, fontSize = 12.sp)
                        }
                        "Settings" -> {
                            PageHeader("Settings") { page = "Home" }
                            Text("Your VPN server and all VLESS settings are managed by the administrator.", color = Dim)
                            OutlinedButton(onClick = { scope.launch { syncProfile(token, true) } }, enabled = !busy) {
                                Text("Check for server update")
                            }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    checkingVersion = true
                                    versionMessage = ""
                                    try {
                                        val result = ZentVersionCheck.latest()
                                        if (result != null && result.isNewer) {
                                            updateInfo = result
                                            versionMessage = "Update available: ${result.version}"
                                        } else versionMessage = "No newer public release found"
                                    } catch (ex: Exception) { versionMessage = "Unable to check for updates" }
                                    finally { checkingVersion = false }
                                }
                            }, enabled = !checkingVersion) { Text("Check for app update") }
                            if (versionMessage.isNotBlank()) Text(versionMessage, color = Dim)
                            if (updateInfo != null) Button(onClick = {
                                val link = updateInfo?.url ?: return@Button
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }) { Text("Download update") }
                        }
                    }
                    if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(24.dp))
                    Text("Zent Plus", fontSize = 11.sp, color = Dim, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                }
            }
            AnimatedVisibility(visible = toast != null,
                enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter).padding(horizontal = 16.dp, vertical = 8.dp)) {
                val current = toast
                if (current != null) Surface(
                    color = when (current.kind) {
                        ToastKind.Success -> Color(0xFF12382F)
                        ToastKind.Error -> Color(0xFF422526)
                        ToastKind.Info -> Color(0xFF17304A)
                    }, shape = RoundedCornerShape(14.dp), shadowElevation = 12.dp
                ) { Text(current.text, color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
            }
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("‹", fontSize = 30.sp, color = Cyan,
            modifier = Modifier.clickable(onClick = onBack).padding(end = 16.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
@Composable
private fun InfoCard(label: String, value: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(17.dp)) {
        Text(label, color = Dim, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(13.dp)).padding(14.dp)) {
        Text(label, color = Dim, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
