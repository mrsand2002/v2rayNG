package com.v2ray.ang.ui.main

import com.v2ray.ang.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

internal data class ZentUpdateInfo(val version: String, val url: String, val isNewer: Boolean)

/** Public release metadata only. Never runs an installer without Android/user confirmation. */
internal object ZentVersionCheck {
    private const val LATEST = "https://api.github.com/repos/mrsand2002/v2rayNG/releases/latest"

    private fun versionParts(value: String): List<Int> {
        return value.trim().removePrefix("v").substringBefore('-')
            .split('.').take(4).map { it.toIntOrNull() ?: 0 }
    }
    private fun newer(candidate: String, current: String): Boolean {
        val a = versionParts(candidate)
        val b = versionParts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val left = a.getOrElse(i) { 0 }
            val right = b.getOrElse(i) { 0 }
            if (left != right) return left > right
        }
        return false
    }
    suspend fun latest(): ZentUpdateInfo? = withContext(Dispatchers.IO) {
        val connection = URL(LATEST).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 9000
            connection.readTimeout = 9000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "ZentPlus/${BuildConfig.VERSION_NAME}")
            if (connection.responseCode == 404) return@withContext null
            if (connection.responseCode !in 200..299) return@withContext null
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val version = json.optString("tag_name").trim().removePrefix("v")
            if (version.isBlank()) return@withContext null
            val assets = json.optJSONArray("assets") ?: return@withContext null
            var apkLink: String? = null
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val name = asset.optString("name")
                val link = asset.optString("browser_download_url")
                if (name.endsWith(".apk", ignoreCase = true) && name.contains("arm64", ignoreCase = true)
                    && link.startsWith("https://github.com/mrsand2002/v2rayNG/releases/download/")) {
                    apkLink = link
                    break
                }
            }
            if (apkLink == null) return@withContext null
            ZentUpdateInfo(version, apkLink, newer(version, BuildConfig.VERSION_NAME))
        } finally { connection.disconnect() }
    }
}
