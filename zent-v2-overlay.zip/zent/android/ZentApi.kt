package com.v2ray.ang.ui.main

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Public URL only; credentials and VLESS profiles are never compiled into the APK. */
internal object ZentApiConfig {
    // The single setting to edit after deploying your independent API server.
    const val BASE_URL = "https://api.example.com"
}

internal data class ZentAccount(
    val username: String,
    val active: Boolean,
    val expirySeconds: Long?,
    val revision: Int,
    val vlessUri: String?
)

internal object ZentApi {
    private suspend fun request(path: String, token: String? = null, data: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
        require(ZentApiConfig.BASE_URL.startsWith("https://") &&
                !ZentApiConfig.BASE_URL.contains("example.com")) {
            "Zent Plus backend has not been configured"
        }
        val connection = URL(ZentApiConfig.BASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 12000
            connection.readTimeout = 12000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
            if (data != null) {
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(data.toString().toByteArray(Charsets.UTF_8)) }
            }
            val success = connection.responseCode in 200..299
            val stream = if (success) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            val response = JSONObject(body)
            if (!success) throw IllegalStateException(response.optString("error", "Request failed (${connection.responseCode})"))
            response
        } finally {
            connection.disconnect()
        }
    }

    suspend fun login(username: String, password: String): String {
        val json = JSONObject().put("username", username).put("password", password)
        val response = request("/api/login", data = json)
        if (response.optJSONObject("user")?.optString("role") != "client") {
            throw IllegalStateException("Customer account required")
        }
        return response.getString("token")
    }

    suspend fun me(token: String): ZentAccount {
        val response = request("/api/me", token)
        val user = response.getJSONObject("user")
        val profile = response.optJSONObject("profile")
        return ZentAccount(
            username = user.getString("username"),
            active = user.optBoolean("active", false),
            expirySeconds = if (user.isNull("expires_at")) null else user.optLong("expires_at"),
            revision = profile?.optInt("revision", 0) ?: 0,
            vlessUri = profile?.optString("uri")?.takeUnless { it.isNullOrBlank() || it == "null" }
        )
    }

    suspend fun logout(token: String) {
        request("/api/logout", token, JSONObject())
    }
}
