package com.v2ray.ang.ui.main

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private val Night = Color(0xFF0A1120)
private val Aqua = Color(0xFF38D9E6)
private val Muted = Color(0xFF9AA9BF)

/** Only customer-allowed controls are exposed: login, connect, disconnect and custom SNI. */
@Composable
fun ZentManagedScreen(
    isRunning: Boolean,
    hasLocalProfile: Boolean,
    onToggleVpn: () -> Unit,
    onStopVpn: () -> Unit,
    onApplyProfile: suspend (String) -> Boolean,
    onClearProfile: () -> Unit,
) {
    val context = LocalContext.current
    val vault = remember(context) { ZentSessionVault(context) }
    val prefs = remember(context) { context.getSharedPreferences("zent_preferences", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(vault.read().orEmpty()) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var account by remember { mutableStateOf<ZentAccount?>(null) }
    var customSni by remember { mutableStateOf(prefs.getString("custom_sni", "").orEmpty()) }
    var editSni by remember { mutableStateOf(customSni) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var appliedMarker by remember { mutableStateOf(prefs.getString("applied_marker", "").orEmpty()) }
    var profileReady by remember { mutableStateOf(hasLocalProfile) }
    // Store a fresh connection attempt so failures cannot look like a dead button.
    var connectAttempt by remember { mutableIntStateOf(0) }
    val latestRunning by rememberUpdatedState(isRunning)
    LaunchedEffect(connectAttempt) {
        if (connectAttempt > 0) {
            delay(10_000)
            if (!latestRunning) {
                message = "VPN did not start. Check VPN permission or the assigned server."
            }
        }
    }
    LaunchedEffect(isRunning) {
        if (isRunning) message = "VPN connected"
    }

    suspend fun syncProfile(authToken: String, force: Boolean = false) {
        busy = true
        try {
            val result = ZentApi.me(authToken)
            if (!result.active) throw IllegalStateException("Your subscription is inactive")
            account = result
            if (result.vlessUri.isNullOrBlank()) {
                profileReady = false
                message = "No VPN profile has been assigned by the administrator"
                return
            }
            val marker = "zent-fix2:${result.username}:${result.revision}:${customSni}"
            if (!profileReady || force || marker != appliedMarker) {
                // Stop existing connection before replacing any stored profile.
                if (isRunning) onStopVpn()
                val configured = ZentSni.apply(result.vlessUri, customSni)
                if (!onApplyProfile(configured)) throw IllegalStateException("Unable to install assigned VLESS profile")
                appliedMarker = marker
                prefs.edit().putString("applied_marker", marker).apply()
                message = "Configuration ready. Tap Connect."
            } else message = "Configuration is up to date"
            profileReady = true
        } catch (ex: Exception) {
            message = ex.message ?: "Unable to connect to management server"
            // Network outage must not silently destroy the existing VPN profile.
            if (message.contains("Login required",true) || message.contains("account expired",true)) {
                if (isRunning) onStopVpn()
                onClearProfile()
                vault.clear()
                token = ""
                profileReady = false
                account = null
            }
        } finally { busy = false }
    }

    LaunchedEffect(token) {
        if (token.isNotBlank()) syncProfile(token)
    }
    LaunchedEffect(token) {
        if (token.isNotBlank()) {
            while (isActive) {
                delay(120_000)
                syncProfile(token)
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Aqua, background = Night, surface = Night)) {
        Column(
            modifier = Modifier.fillMaxSize().background(Night)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 26.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("ZENT+", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Aqua)
            Text("YOUR CONNECTION. SIMPLIFIED.", fontSize = 11.sp, color = Muted)
            Spacer(Modifier.height(30.dp))
            if (token.isBlank()) {
                Text("Customer sign in", fontSize = 22.sp, color = Color.White)
                OutlinedTextField(username, {username=it}, label={Text("Username")}, singleLine=true,
                    modifier=Modifier.fillMaxWidth())
                OutlinedTextField(password, {password=it}, label={Text("Password")},
                    singleLine=true, visualTransformation=PasswordVisualTransformation(),
                    modifier=Modifier.fillMaxWidth())
                Button(onClick = {
                    scope.launch {
                        busy = true
                        try {
                            val newToken = ZentApi.login(username.trim(), password)
                            vault.save(newToken)
                            password = ""
                            token = newToken
                            message = "Login successful"
                        } catch (ex: Exception) {
                            message = ex.message ?: "Login failed"
                        } finally { busy = false }
                    }
                }, enabled = !busy && username.isNotBlank() && password.isNotBlank(),
                    modifier=Modifier.fillMaxWidth()) { Text("SIGN IN") }
            } else {
                Text("Welcome, ${account?.username ?: "customer"}", color=Color.White, fontSize=19.sp)
                Text(if (isRunning) "VPN RUNNING" else "VPN STOPPED", fontSize=22.sp,
                    color=if (isRunning) Aqua else Color.White, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(15.dp))
                Button(onClick = {
                    when {
                        isRunning -> {
                            message = "Disconnecting VPN..."
                            onToggleVpn()
                        }
                        account?.active != true -> {
                            message = "Account is not active. Tap Check for server update."
                        }
                        !profileReady || !hasLocalProfile -> {
                            message = "No VPN profile is ready. Fetching your assigned server..."
                            scope.launch { syncProfile(token, force = true) }
                        }
                        else -> {
                            message = "Starting VPN — approve the Android VPN permission prompt if shown."
                            try {
                                onToggleVpn()
                                connectAttempt += 1
                            } catch (ex: Exception) {
                                message = "Unable to request VPN start: ${ex.message ?: "unknown error"}"
                            }
                        }
                    }
                },
                    enabled = !busy,
                    shape=CircleShape,
                    modifier=Modifier.size(188.dp),
                    colors=ButtonDefaults.buttonColors(containerColor=Aqua, contentColor=Night)) {
                    Text(if(isRunning) "DISCONNECT" else "CONNECT", fontWeight=FontWeight.Black, fontSize=19.sp)
                }
                Text(if (profileReady) "Server assigned by administrator" else "No active VPN profile",
                    color=Muted, textAlign=TextAlign.Center)
                account?.expirySeconds?.let {
                    Text("Expires: ${DateFormat.getDateInstance().format(Date(it*1000))}", color=Muted)
                }
                Spacer(Modifier.height(20.dp))
                HorizontalDivider(color=Color(0xFF23344B))
                Text("CUSTOM SNI", color=Aqua, fontWeight=FontWeight.Bold, modifier=Modifier.fillMaxWidth())
                OutlinedTextField(value=editSni, onValueChange={editSni=it},
                    label={Text("SNI hostname")}, placeholder={Text("Default (set by admin)")},
                    singleLine=true, modifier=Modifier.fillMaxWidth())
                Text("Leave blank to use the server's default SNI. A wrong SNI can prevent connection.",
                    color=Muted, fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick={ editSni="" }, modifier=Modifier.weight(1f)) { Text("Reset") }
                    Button(onClick={
                        val s=editSni.trim()
                        if (s.isNotBlank() && !ZentSni.isValid(s)) {
                            message="Please enter a valid SNI hostname"
                        } else {
                            customSni=s
                            prefs.edit().putString("custom_sni",s).apply()
                            scope.launch {syncProfile(token, force=true)}
                        }
                    }, modifier=Modifier.weight(1f), enabled=!busy) { Text("Save SNI") }
                }
                OutlinedButton(onClick={scope.launch {syncProfile(token)}}, enabled=!busy,
                    modifier=Modifier.fillMaxWidth()) {Text("Check for server update")}
                TextButton(onClick={
                    scope.launch {
                        if (isRunning) onStopVpn()
                        try { ZentApi.logout(token) } catch (_: Exception) {}
                        onClearProfile()
                        vault.clear()
                        prefs.edit().remove("applied_marker").apply()
                        profileReady=false
                        account=null
                        token=""
                        message="Signed out"
                    }
                }) {Text("Sign out", color=Muted)}
            }
            if (busy) LinearProgressIndicator(modifier=Modifier.fillMaxWidth())
            if (message.isNotBlank()) Text(message, color=Color(0xFFB8E6FF), textAlign=TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Text("Zent Plus · Powered by open-source Xray", fontSize=11.sp, color=Muted)
        }
    }
}
