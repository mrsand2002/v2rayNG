#!/usr/bin/env python3
"""Apply customer-app overlay to a checked-out v2rayNG fork inside GitHub Actions.
Rejects unexpected source layout rather than silently corrupting the project."""
import os
import re
import shutil
from pathlib import Path
from urllib.parse import urlsplit

root = Path.cwd()
base = root / 'V2rayNG/app/src/main/java/com/v2ray/ang/ui/main'
mainfile = base / 'MainActivity.kt'
assert mainfile.is_file(), f'Cannot locate {mainfile}'
api_url = os.environ.get('ZENT_API_URL', '').rstrip('/')
p = urlsplit(api_url)
if p.scheme != 'https' or not p.hostname or p.username or p.password or p.path or p.query or p.fragment or len(api_url)>253:
    raise SystemExit('ZENT_API_URL must be a public HTTPS origin, e.g. https://api.myvpn.example')
for name in ('ZentApi.kt', 'ZentSessionVault.kt', 'ZentManagedScreen.kt'):
    source = root / 'zent/android' / name
    if not source.is_file(): raise SystemExit(f'Missing {source}')
    content=source.read_text(encoding='utf-8')
    if name=='ZentApi.kt':
        content=content.replace('"https://api.example.com"',repr(api_url).replace("'",'"'))
        if 'https://api.example.com' in content: raise SystemExit('API URL not replaced')
    (base/name).write_text(content, encoding='utf-8')

source=mainfile.read_text(encoding='utf-8')
imports='''import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.handler.MmkvManager
'''
for line in imports.splitlines():
    if line not in source:
        source=source.replace('import androidx.compose.runtime.Composable',line+'\nimport androidx.compose.runtime.Composable',1)
if 'import kotlinx.coroutines.withContext' not in source:
    source=source.replace('import androidx.compose.runtime.Composable', 'import kotlinx.coroutines.withContext\nimport androidx.compose.runtime.Composable',1)

replacement='''    @Composable
    override fun ScreenContent() {
        BackHandler { moveTaskToBack(false) }
        val state by mainViewModel.uiState.collectAsStateWithLifecycle()
        ZentManagedScreen(
            isRunning = state.isRunning,
            hasLocalProfile = !state.selectedGuid.isNullOrBlank(),
            onToggleVpn = {
                // Zent Plus is a VPN app, never proxy-only mode.
                if (!SettingsManager.isVpnMode()) {
                    MmkvManager.encodeSettings(AppConfig.PREF_MODE, AppConfig.VPN)
                }
                handleFabAction()
            },
            onStopVpn = { LauncherManager.stopService(this) },
            onApplyProfile = { newUri ->
                val newGuid = withContext(Dispatchers.IO) {
                    // Verify the new profile really exists before selecting it.
                    // The first server in storage might be a stale/other server.
                    val before = MmkvManager.decodeAllServerList().toSet()
                    val count = AngConfigManager.importBatchConfig(newUri, "", false).first
                    if (count != 1) null else {
                        MmkvManager.decodeAllServerList().firstOrNull { guid ->
                            guid !in before &&
                                MmkvManager.decodeServerConfig(guid)?.configType == EConfigType.VLESS
                        }
                    }
                }
                if (newGuid != null) {
                    mainViewModel.updateSelectedGuid(newGuid)
                    mainViewModel.onAction(MainAction.RefreshGroups)
                    true
                } else false
            },
            onClearProfile = {
                MmkvManager.removeAllServer()
                mainViewModel.updateSelectedGuid("")
                mainViewModel.onAction(MainAction.RefreshGroups)
            }
        )
    }

'''
start_re=re.compile(r'(?m)^\s*@Composable\s*\n\s*override fun ScreenContent\(\)\s*\{')
start=start_re.search(source)
if not start: raise SystemExit('MainActivity.ScreenContent() not found: inspect fork before patching')
end=re.search(r'(?m)^\s*private fun shareToClipboard\(',source[start.end():])
if not end: raise SystemExit('MainActivity.shareToClipboard() anchor not found')
end_offset=start.end()+end.start()
source=source[:start.start()]+'\n'+replacement+source[end_offset:]
mainfile.write_text(source,encoding='utf-8')

strings=root/'V2rayNG/app/src/main/res/values/strings.xml'
if strings.is_file():
    contents=strings.read_text(encoding='utf-8')
    contents,count=re.subn(r'<string name="app_name"([^>]*)>[^<]*</string>',r'<string name="app_name"\1>Zent Plus</string>',contents,count=1)
    if not count: raise SystemExit('App name string not found')
    strings.write_text(contents,encoding='utf-8')

# Prevent leftover v2rayNG external import, quick tile and Tasker entrypoints from
# bypassing the customer-only UI. Keep the VPN engine service itself intact.
manifest = root/'V2rayNG/app/src/main/AndroidManifest.xml'
if not manifest.is_file(): raise SystemExit('AndroidManifest.xml not found')
xml = manifest.read_text(encoding='utf-8')
for kind, name in (
    ('activity', '.ui.UrlSchemeActivity'),
    ('activity', '.ui.shortcut.TaskerActivity'),
    ('receiver', '.receiver.TaskerReceiver'),
):
    regex = re.compile(r'(<'+kind+r'\b[^>]*?android:name="'+re.escape(name)+r'"[^>]*?android:exported=")true("[^>]*>)',re.S)
    xml, count = regex.subn(r'\1false\2',xml, count=1)
    if count != 1: raise SystemExit('Missing exported manifest component: '+name)
for kind, name in (
    ('service', '.service.QSTileService'),
    ('receiver', '.receiver.WidgetProvider'),
    ('receiver', '.receiver.BootReceiver'),
):
    regex = re.compile(r'(<'+kind+r'\b[^>]*?android:name="'+re.escape(name)+r'"\s*)',re.S)
    xml, count=regex.subn(r'\1android:enabled="false"\n        ',xml,count=1)
    if count != 1: raise SystemExit('Missing auto-start / shortcut manifest component: '+name)
manifest.write_text(xml,encoding='utf-8')
print('Zent Plus customer UI, API client, token vault and profile-sync integration applied.')

# Zent Plus branding. Keep existing native engine and VPN service registrations untouched.
icon_assets = root / 'zent/assets'
android_res = root / 'V2rayNG/app/src/main/res'
if not icon_assets.is_dir(): raise SystemExit('Missing branded icon assets')
for file in icon_assets.rglob('*'):
    if file.is_file():
        dst = android_res / file.relative_to(icon_assets)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(file, dst)
manifest = root / 'V2rayNG/app/src/main/AndroidManifest.xml'
xml = manifest.read_text(encoding='utf-8')
# Scope replacement to <application> header so Tasker/notification icons don't change.
match = re.search(r'<application\b[^>]*>', xml, re.S)
if not match: raise SystemExit('Cannot find <application> header for branded launcher')
application = match.group(0)
if 'android:icon="@mipmap/ic_launcher"' not in application:
    raise SystemExit('Original application icon not found; review icon patch')
application = application.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/zent_launcher"', 1)
if 'android:roundIcon=' in application:
    application = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/zent_launcher"', application, count=1)
else:
    application = application.replace('<application', '<application\n    android:roundIcon="@mipmap/zent_launcher"', 1)
xml = xml[:match.start()] + application + xml[match.end():]
manifest.write_text(xml, encoding='utf-8')
print('Zent Plus launcher icon installed; old unused customer menus remain hidden.')
