package com.v2ray.ang.ui.main

import android.content.Context
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import android.net.TrafficStats
import android.net.Uri
import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.io.File
import java.security.MessageDigest
import java.util.Date
import kotlin.math.max

private data class ZentPalette(
    val background: Color,
    val accent: Color,
    val mutedText: Color,
    val card: Color,
    val mainText: Color
)
private val DarkPalette = ZentPalette(
    background = Color(0xFF0A1120), accent = Color(0xFF38D9E6),
    mutedText = Color(0xFF9AAFC6), card = Color(0xFF16263A),
    mainText = Color(0xFFFFFFFF)
)
private val LightPalette = ZentPalette(
    background = Color(0xFFF5F9FC), accent = Color(0xFF007C91),
    mutedText = Color(0xFF526A7F), card = Color(0xFFE7F1F7),
    mainText = Color(0xFF13263A)
)
private val LocalZentPalette = staticCompositionLocalOf { DarkPalette }
private val Navy: Color @Composable get() = LocalZentPalette.current.background
private val Cyan: Color @Composable get() = LocalZentPalette.current.accent
private val Dim: Color @Composable get() = LocalZentPalette.current.mutedText
private val Panel: Color @Composable get() = LocalZentPalette.current.card
private val Ink: Color @Composable get() = LocalZentPalette.current.mainText

/** Names are local preferences only: they never change an account's login identity. */
private fun localAccountKey(username: String): String = MessageDigest.getInstance("SHA-256")
    .digest(username.toByteArray(Charsets.UTF_8)).take(12)
    .joinToString("") { "%02x".format(it.toInt() and 0xff) }

private fun accountProfilePrefs(context: Context, username: String) =
    context.getSharedPreferences("zent_user_" + localAccountKey(username), Context.MODE_PRIVATE)

private fun avatarPath(context: Context, username: String): File =
    File(context.filesDir, "zent_avatar_" + localAccountKey(username) + ".jpg")

/** Copies a gallery image to app-private storage; no cloud upload or storage permission. */
private fun savePrivateAvatar(context: Context, username: String, uri: Uri): Boolean {
    return try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
    var sampleSize = 1
    while (max(bounds.outWidth, bounds.outHeight) / sampleSize > 900) sampleSize *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    val bitmap = context.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, options)
    } ?: return false
    val scale = 512f / max(bitmap.width, bitmap.height)
    val scaled = if (scale < 1f) Bitmap.createScaledBitmap(
        bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1),
        (bitmap.height * scale).toInt().coerceAtLeast(1), true
    ) else bitmap
    val destination = avatarPath(context, username)
    val success = destination.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    if (scaled !== bitmap) scaled.recycle()
    bitmap.recycle()
    success
    } catch (_: Exception) { false }
}

private fun readPrivateAvatar(context: Context, username: String): Bitmap? =
    try { avatarPath(context, username).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.absolutePath) } }
    catch (_: Exception) { null }

@Composable
private fun ZentAvatar(photo: Bitmap?, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Panel),
        contentAlignment = Alignment.Center) {
        if (photo != null) Image(photo.asImageBitmap(), contentDescription = "Profile picture",
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text("👤", fontSize = (size.value * .48f).sp, color = Cyan)
    }
}

private enum class ToastKind { Info, Success, Error }
private data class ToastNotice(val text: String, val kind: ToastKind, val id: Int)

private fun readableBytes(bytes: Long): String {
    val b = bytes.coerceAtLeast(0).toDouble()
    return when {
        b >= 1024.0 * 1024 * 1024 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
        b >= 1024.0 * 1024 -> "%.1f MB".format(b / (1024.0 * 1024))
        b >= 1024 -> "%.0f KB".format(b / 1024)
        else -> "${bytes.coerceAtLeast(0)} B"
    }
}
private fun readableDuration(milliseconds: Long): String {
    val s = milliseconds.coerceAtLeast(0) / 1000
    return "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
}

/** Customer-only experience. VPN profile/server/TLS/SNI are centrally assigned. */
@Composable
fun ZentManagedScreen(
    isRunning: Boolean,
    hasLocalProfile: Boolean,
    onStartVpn: () -> Unit,
    onStopVpn: () -> Unit,
    onApplyProfile: suspend (String) -> Boolean,
    onClearProfile: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vault = remember(context) { ZentSessionVault(context) }
    val prefs = remember(context) { context.getSharedPreferences("zent_preferences", Context.MODE_PRIVATE) }
    var token by remember { mutableStateOf(vault.read().orEmpty()) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var account by remember { mutableStateOf<ZentAccount?>(null) }
    var busy by remember { mutableStateOf(false) }
    var profileReady by remember { mutableStateOf(hasLocalProfile) }
    var appliedMarker by remember { mutableStateOf(prefs.getString("applied_marker", "").orEmpty()) }
    var toast by remember { mutableStateOf<ToastNotice?>(null) }
    var noticeId by remember { mutableIntStateOf(0) }
    var connecting by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var page by remember { mutableStateOf("Home") }
    var showLogoutConfirmation by remember { mutableStateOf(false) }
    var showAbout by remember { mutableStateOf(false) }
    var versionMessage by remember { mutableStateOf("") }
    var updateInfo by remember { mutableStateOf<ZentUpdateInfo?>(null) }
    var checkingVersion by remember { mutableStateOf(false) }
    var appearanceMode by remember { mutableStateOf(
        prefs.getString("appearance_mode", "system") ?: "system"
    ) }
    val systemDark = isSystemInDarkTheme()
    val darkMode = when (appearanceMode) {
        "light" -> false
        "dark" -> true
        else -> systemDark
    }
    val palette = if (darkMode) DarkPalette else LightPalette
    // Keep Android status/navigation icons readable as the selected theme changes.
    val activity = context as? Activity
    SideEffect {
        activity?.window?.let { window ->
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.isAppearanceLightStatusBars = !darkMode
            controller.isAppearanceLightNavigationBars = !darkMode
        }
    }

    // Session stats: Android's app-UID traffic, not 3X-UI account-wide usage.
    var rxSpeed by remember { mutableLongStateOf(0L) }
    var txSpeed by remember { mutableLongStateOf(0L) }
    var sessionRx by remember { mutableLongStateOf(0L) }
    var sessionTx by remember { mutableLongStateOf(0L) }
    var uptimeMs by remember { mutableLongStateOf(0L) }
    var statsAvailable by remember { mutableStateOf(true) }
    fun notify(text: String, kind: ToastKind = ToastKind.Info) {
        noticeId += 1
        toast = ToastNotice(text, kind, noticeId)
    }

    // Scoped per login username, entirely local to this phone.
    var displayName by remember { mutableStateOf("") }
    var displayNameDraft by remember { mutableStateOf("") }
    var avatarRevision by remember { mutableIntStateOf(0) }
    val profilePhoto = remember(account?.username, avatarRevision) {
        account?.username?.let { readPrivateAvatar(context, it) }
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selected ->
        val currentUsername = account?.username
        if (selected != null && currentUsername != null) {
            if (savePrivateAvatar(context, currentUsername, selected)) {
                avatarRevision++
                notify("Profile picture updated", ToastKind.Success)
            } else notify("Couldn't read that picture. Choose another image.", ToastKind.Error)
        }
    }
    LaunchedEffect(account?.username) {
        val currentUsername = account?.username
        displayName = currentUsername?.let {
            accountProfilePrefs(context, it).getString("display_name", "").orEmpty()
        }.orEmpty()
        displayNameDraft = displayName
        avatarRevision++
    }


    LaunchedEffect(toast?.id) {
        val current = toast ?: return@LaunchedEffect
        delay(if (current.kind == ToastKind.Error) 6500 else 3200)
        if (toast?.id == current.id) toast = null
    }
    LaunchedEffect(Unit) { prefs.edit().remove("custom_sni").apply() }
    LaunchedEffect(isRunning) {
        if (isRunning) {
            connecting = false
            notify("VPN service active", ToastKind.Success)
            val startedAt = SystemClock.elapsedRealtime()
            var previousAt = startedAt
            var previousRx = TrafficStats.getUidRxBytes(context.applicationInfo.uid)
            var previousTx = TrafficStats.getUidTxBytes(context.applicationInfo.uid)
            statsAvailable = previousRx >= 0 && previousTx >= 0
            sessionRx = 0
            sessionTx = 0
            while (isActive) {
                delay(2000)
                val now = SystemClock.elapsedRealtime()
                uptimeMs = now - startedAt
                if (!statsAvailable) continue
                val newRx = TrafficStats.getUidRxBytes(context.applicationInfo.uid)
                val newTx = TrafficStats.getUidTxBytes(context.applicationInfo.uid)
                if (newRx < 0 || newTx < 0) { statsAvailable = false; continue }
                val elapsed = (now - previousAt).coerceAtLeast(1)
                val rx = max(0, newRx - previousRx)
                val tx = max(0, newTx - previousTx)
                rxSpeed = rx * 1000 / elapsed
                txSpeed = tx * 1000 / elapsed
                sessionRx += rx
                sessionTx += tx
                previousRx = newRx
                previousTx = newTx
                previousAt = now
            }
        } else {
            rxSpeed = 0
            txSpeed = 0
            uptimeMs = 0
        }
    }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(12000)
            if (connecting && !isRunning) {
                connecting = false
                notify("VPN did not start. Check the profile or VPN permission.", ToastKind.Error)
            }
        }
    }

    suspend fun syncProfile(authToken: String, force: Boolean = false) {
        if (busy) return
        busy = true
        try {
            val fetched = ZentApi.me(authToken)
            if (!fetched.active) throw IllegalStateException("Account inactive or expired")
            account = fetched
            val newUri = fetched.vlessUri
            if (newUri.isNullOrBlank()) {
                profileReady = false
                notify("No VPN server assigned to this account", ToastKind.Error)
                return
            }
            val marker = "zent-managed-v2:${fetched.username}:${fetched.revision}"
            if (force || !profileReady || marker != appliedMarker) {
                val reconnect = isRunning
                if (reconnect) onStopVpn()
                if (reconnect) delay(1800)
                if (!onApplyProfile(newUri)) {
                    throw IllegalStateException("Unable to install your assigned VPN profile")
                }
                prefs.edit().putString("applied_marker", marker).apply()
                appliedMarker = marker
                profileReady = true
                notify("VPN configuration updated", ToastKind.Success)
                if (reconnect) {
                    delay(900)
                    connecting = true
                    onStartVpn()
                }
            } else profileReady = true
        } catch (ex: Exception) {
            val err = ex.message ?: "Management server unavailable"
            notify(err.take(120), ToastKind.Error)
            if (err.contains("Login required", true) || err.contains("account expired", true)) {
                if (isRunning) onStopVpn()
                onClearProfile()
                vault.clear()
                token = ""
                profileReady = false
                account = null
            }
        } finally { busy = false }
    }

    LaunchedEffect(token) {
        if (token.isNotBlank()) syncProfile(token)
    }
    LaunchedEffect(token) {
        if (token.isNotBlank()) while (isActive) {
            delay(120_000)
            syncProfile(token)
        }
    }
    LaunchedEffect(token) {
        if (token.isNotBlank()) {
            val info = runCatching { ZentVersionCheck.latest() }.getOrNull()
            if (info != null && info.isNewer) {
                updateInfo = info
                notify("New Zent Plus update available", ToastKind.Info)
            }
        }
    }

    CompositionLocalProvider(LocalZentPalette provides palette) {
        MaterialTheme(colorScheme = if (darkMode) darkColorScheme(
            primary = palette.accent, background = palette.background,
            surface = palette.card, onSurface = palette.mainText,
            onBackground = palette.mainText
        ) else lightColorScheme(
            primary = palette.accent, background = palette.background,
            surface = palette.card, onSurface = palette.mainText,
            onBackground = palette.mainText
        )) {
    if (showLogoutConfirmation) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmation = false },
            title = { Text("Sign out of Zent Plus?") },
            text = { Text("You'll need to sign in again to use your account.") },
            confirmButton = { TextButton(onClick = {
                showLogoutConfirmation = false
                scope.launch {
                    busy = true
                    if (isRunning) onStopVpn()
                    try { ZentApi.logout(token) } catch (_: Exception) { }
                    onClearProfile()
                    vault.clear()
                    prefs.edit().remove("applied_marker").apply()
                    appliedMarker = ""
                    profileReady = false
                    token = ""
                    account = null
                    page = "Home"
                    drawerState.close()
                    busy = false
                }
            }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { showLogoutConfirmation = false }) { Text("Cancel") } }
        )
    }
    if (showAbout) {
        val version = remember(context) {
            runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Unknown" }
                .getOrDefault("Unknown")
        }
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Zent Plus", color = Cyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Version  $version")
                    Text("Tharusha Sandeepa")
                }
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Close") } }
        )
    }

        Box(Modifier.fillMaxSize().background(Navy).windowInsetsPadding(WindowInsets.safeDrawing)) {
            if (token.isBlank()) {
                Box(Modifier.fillMaxSize().imePadding()) {
                    Column(
                        modifier = Modifier.align(Alignment.Center).fillMaxWidth()
                            .padding(horizontal = 28.dp).verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text("ZENT+", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Cyan)
                        Spacer(Modifier.height(12.dp))
                        Text("User Sign In", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(username, { username = it }, label = { Text("Username") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(password, { password = it }, label = { Text("Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val session = ZentApi.login(username.trim(), password)
                                    vault.save(session)
                                    password = ""
                                    token = session
                                    notify("Signed in successfully", ToastKind.Success)
                                } catch (ex: Exception) {
                                    notify(ex.message ?: "Sign-in failed", ToastKind.Error)
                                } finally { busy = false }
                            }
                        }, enabled = !busy && username.isNotBlank() && password.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()) { Text("SIGN IN") }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            } else ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = token.isNotBlank(),
                drawerContent = {
                    ModalDrawerSheet(drawerContainerColor = Panel, modifier = Modifier.width(290.dp)) {
                        Spacer(Modifier.height(30.dp))
                        Text("ZENT+", color = Cyan, fontWeight = FontWeight.Black, fontSize = 30.sp,
                            modifier = Modifier.padding(horizontal = 24.dp))
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            ZentAvatar(profilePhoto, 54.dp)
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(displayName.ifBlank { "Zent Plus User" },
                                    color = Ink, fontWeight = FontWeight.SemiBold,
                                    maxLines = 1)
                                val status = when {
                                    account == null -> "Checking..."
                                    account?.active == true -> "Active"
                                    else -> "Inactive"
                                }
                                val statusColor = when {
                                    account == null -> Dim
                                    account?.active == true -> Color(0xFF55DDA4)
                                    else -> Color(0xFFFF8383)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(9.dp).background(statusColor, CircleShape))
                                    Spacer(Modifier.width(7.dp))
                                    Text(status, color = statusColor, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 18.dp))
                        listOf("My Profile", "Data Usage", "Settings", "About Zent Plus").forEach { item ->
                            NavigationDrawerItem(
                                label = { Text(item) },
                                selected = page == item,
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    if (item == "About Zent Plus") showAbout = true else page = item
                                }, modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            scope.launch { drawerState.close() }
                            showLogoutConfirmation = true
                        }, modifier = Modifier.padding(20.dp)) { Text("Sign out", color = Color(0xFFFF9292)) }
                    }
                }
            ) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (token.isNotBlank()) {
                            Text("☰", color = Ink, fontSize = 29.sp,
                                modifier = Modifier.clickable { scope.launch { drawerState.open() } }.padding(end = 18.dp))
                        }
                        Text("ZENT+", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Cyan)
                        Spacer(Modifier.weight(1f))
                        if (updateInfo != null) {
                            TextButton(onClick = {
                                val link = updateInfo?.url ?: return@TextButton
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }) { Text("Update") }
                        }
                    }
                    when (page) {
                        "Home" -> {
                            Spacer(Modifier.height(45.dp))
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(when {
                                    isRunning -> "VPN SERVICE ACTIVE"
                                    connecting -> "CONNECTING..."
                                    else -> "DISCONNECTED"
                                }, color = if(isRunning) Cyan else Ink, fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp)
                                Button(onClick = {
                                    when {
                                        isRunning -> { onStopVpn(); notify("VPN disconnected") }
                                        account?.active != true -> notify("Account not active", ToastKind.Error)
                                        !profileReady || !hasLocalProfile -> {
                                            notify("Fetching your assigned VPN profile")
                                            scope.launch { syncProfile(token, true) }
                                        }
                                        else -> {
                                            connecting = true
                                            notify("Connecting… approve VPN permission if requested")
                                            try { onStartVpn() } catch (ex: Exception) {
                                                connecting = false
                                                notify(ex.message ?: "Unable to start VPN", ToastKind.Error)
                                            }
                                        }
                                    }
                                }, modifier = Modifier.size(186.dp), shape = CircleShape, enabled = !busy,
                                    colors = ButtonDefaults.buttonColors(containerColor = Cyan,
                                        contentColor = if (darkMode) Navy else Color.White)) {
                                    Text(if(isRunning) "DISCONNECT" else "CONNECT", fontWeight = FontWeight.Black, fontSize = 17.sp)
                                }
                                Text(if (profileReady) "server managed by Mr.මල" else "No VPN profile assigned",
                                    color = Dim)
                            }
                            Spacer(Modifier.height(15.dp))
                            // UID counters are estimates for this device, not 3X-UI lifetime data.
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("Download", if (statsAvailable) "${readableBytes(rxSpeed)}/s" else "Unavailable", Modifier.weight(1f))
                                StatCard("Upload", if (statsAvailable) "${readableBytes(txSpeed)}/s" else "Unavailable", Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard("Session", readableDuration(uptimeMs), Modifier.weight(1f))
                                StatCard("Session traffic", if (statsAvailable) readableBytes(sessionRx + sessionTx) else "Unavailable", Modifier.weight(1f))
                            }
                        }
                        "My Profile" -> {
                            PageHeader("My Profile") { page = "Home" }
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                ZentAvatar(profilePhoto, 104.dp)
                                OutlinedButton(onClick = { avatarPicker.launch("image/*") },
                                    enabled = account?.username != null) { Text("Change Profile Picture") }
                                if (profilePhoto != null) TextButton(onClick = {
                                    account?.username?.let { avatarPath(context, it).delete() }
                                    avatarRevision++
                                    notify("Profile picture removed", ToastKind.Success)
                                }) { Text("Remove Picture") }
                            }
                            OutlinedTextField(
                                value = displayNameDraft,
                                onValueChange = { displayNameDraft = it.take(40) },
                                label = { Text("Display Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(onClick = {
                                val savedName = displayNameDraft.trim()
                                val saved = account?.username?.let { user ->
                                    accountProfilePrefs(context, user).edit()
                                        .putString("display_name", savedName).commit()
                                } == true
                                if (saved) {
                                    displayName = savedName
                                    page = "Home"
                                    notify("Profile Updated Successfully!", ToastKind.Success)
                                } else {
                                    notify("Unable to save profile. Please retry.", ToastKind.Error)
                                }
                            }, modifier = Modifier.fillMaxWidth(), enabled = account?.username != null) {
                                Text("Save Profile")
                            }
                            InfoCard("Login username", account?.username ?: "—")
                            InfoCard("Subscription", if(account?.active == true) "Active" else "Inactive")
                            InfoCard("Expires", account?.expirySeconds?.let {
                                DateFormat.getDateInstance().format(Date(it * 1000))
                            } ?: "No expiry set")
                        }
                        "Data Usage" -> {
                            PageHeader("Data Usage") { page = "Home" }
                            InfoCard("Data allowance", "Unlimited ∞")
                            InfoCard("This VPN session — Download", if (statsAvailable) readableBytes(sessionRx) else "Unavailable")
                            InfoCard("This VPN session — Upload", if (statsAvailable) readableBytes(sessionTx) else "Unavailable")
                            InfoCard("This VPN session — Total", if (statsAvailable) readableBytes(sessionRx + sessionTx) else "Unavailable")
                        }
                        "Settings" -> {
                            PageHeader("Settings") { page = "Home" }
                            Text("Appearance", color = Ink, fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp)
                            listOf(
                                "system" to "Follow System",
                                "light" to "Light Mode",
                                "dark" to "Dark Mode"
                            ).forEach { (mode, label) ->
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        appearanceMode = mode
                                        prefs.edit().putString("appearance_mode", mode).apply()
                                    }.padding(vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = appearanceMode == mode, onClick = {
                                        appearanceMode = mode
                                        prefs.edit().putString("appearance_mode", mode).apply()
                                    })
                                    Spacer(Modifier.width(8.dp))
                                    Text(label, color = Ink)
                                }
                            }
                            HorizontalDivider()
                            OutlinedButton(onClick = { scope.launch { syncProfile(token, true) } }, enabled = !busy) {
                                Text("Check for server update")
                            }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    checkingVersion = true
                                    versionMessage = ""
                                    try {
                                        val result = ZentVersionCheck.latest()
                                        if (result != null && result.isNewer) {
                                            updateInfo = result
                                            versionMessage = "Update available: ${result.version}"
                                        } else versionMessage = "No newer public release found"
                                    } catch (ex: Exception) { versionMessage = "Unable to check for updates" }
                                    finally { checkingVersion = false }
                                }
                            }, enabled = !checkingVersion) { Text("Check for app update") }
                            if (versionMessage.isNotBlank()) Text(versionMessage, color = Dim)
                            if (updateInfo != null) Button(onClick = {
                                val link = updateInfo?.url ?: return@Button
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }) { Text("Download update") }
                        }
                    }
                    if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(24.dp))
                    Text("Zent Plus", fontSize = 11.sp, color = Dim, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                }
            }
            AnimatedVisibility(visible = toast != null,
                enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter).padding(horizontal = 16.dp, vertical = 8.dp)) {
                val current = toast
                if (current != null) Surface(
                    color = when (current.kind) {
                        ToastKind.Success -> Color(0xFF12382F)
                        ToastKind.Error -> Color(0xFF422526)
                        ToastKind.Info -> Color(0xFF17304A)
                    }, shape = RoundedCornerShape(14.dp), shadowElevation = 12.dp
                ) { Text(current.text, color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) }
            }
        }
    }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("‹", fontSize = 30.sp, color = Cyan,
            modifier = Modifier.clickable(onClick = onBack).padding(end = 16.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}
@Composable
private fun InfoCard(label: String, value: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(17.dp)) {
        Text(label, color = Dim, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(13.dp)).padding(14.dp)) {
        Text(label, color = Dim, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
