#!/usr/bin/env python3
"""Patch the pinned v2rayNG fork into Zent Plus before building on GitHub Actions.
Fail closed on source mismatch. Never modifies the running VPS or Railway backend.
"""
import os
import re
import shutil
from pathlib import Path
from urllib.parse import urlsplit

root = Path.cwd()
app = root / 'V2rayNG/app'
base = app / 'src/main/java/com/v2ray/ang/ui/main'
mainfile = base / 'MainActivity.kt'
gradle = app / 'build.gradle.kts'
manifest = app / 'src/main/AndroidManifest.xml'
assert mainfile.is_file() and gradle.is_file() and manifest.is_file(), 'Unsupported fork directory layout'
api_url = os.environ.get('ZENT_API_URL', '').rstrip('/')
p = urlsplit(api_url)
if p.scheme != 'https' or not p.hostname or p.username or p.password or p.path or p.query or p.fragment:
    raise SystemExit('ZENT_API_URL must be just the HTTPS origin (no /admin path)')

for filename in ('ZentApi.kt', 'ZentSessionVault.kt', 'ZentVersionCheck.kt', 'ZentManagedScreen.kt'):
    contents = (root/'zent/android'/filename).read_text(encoding='utf-8')
    if filename == 'ZentApi.kt':
        contents = contents.replace('https://api.example.com', api_url)
        assert 'https://api.example.com' not in contents
    (base / filename).write_text(contents, encoding='utf-8')

source = mainfile.read_text(encoding='utf-8')
for line in (
    'import androidx.compose.runtime.getValue',
    'import androidx.lifecycle.compose.collectAsStateWithLifecycle',
    'import com.v2ray.ang.handler.MmkvManager',
    'import kotlinx.coroutines.withContext',
):
    if line not in source:
        assert 'import androidx.compose.runtime.Composable' in source
        source = source.replace('import androidx.compose.runtime.Composable', line+'\nimport androidx.compose.runtime.Composable', 1)

replacement = '''    @Composable
    override fun ScreenContent() {
        BackHandler { moveTaskToBack(false) }
        val state by mainViewModel.uiState.collectAsStateWithLifecycle()
        ZentManagedScreen(
            isRunning = state.isRunning,
            hasLocalProfile = !state.selectedGuid.isNullOrBlank(),
            onStartVpn = {
                // Always enter Android VpnService mode; don't accidentally start only a proxy.
                if (!SettingsManager.isVpnMode()) {
                    MmkvManager.encodeSettings(AppConfig.PREF_MODE, AppConfig.VPN)
                }
                requestServiceStart()
            },
            onStopVpn = { LauncherManager.stopService(this) },
            onApplyProfile = { uri ->
                val newGuid = withContext(Dispatchers.IO) {
                    val before = MmkvManager.decodeAllServerList().toSet()
                    val result = AngConfigManager.importBatchConfig(uri, "", false).first
                    if (result != 1) null else {
                        val all = MmkvManager.decodeAllServerList()
                        (all.filter { it !in before } + all.filter { it in before }).firstOrNull { guid ->
                            MmkvManager.decodeServerConfig(guid)?.configType == EConfigType.VLESS
                        }
                    }
                }
                if (newGuid != null) {
                    mainViewModel.updateSelectedGuid(newGuid)
                    mainViewModel.onAction(MainAction.RefreshGroups)
                    true
                } else false
            },
            onClearProfile = {
                MmkvManager.removeAllServer()
                mainViewModel.updateSelectedGuid("")
                mainViewModel.onAction(MainAction.RefreshGroups)
            }
        )
    }

'''
start = re.search(r'(?m)^\s*@Composable\s*\n\s*override fun ScreenContent\(\)\s*\{', source)
if not start: raise SystemExit('ScreenContent anchor missing')
end = re.search(r'(?m)^\s*private fun shareToClipboard\(', source[start.end():])
if not end: raise SystemExit('shareToClipboard anchor missing')
source = source[:start.start()] + '\n' + replacement + source[start.end()+end.start():]
mainfile.write_text(source, encoding='utf-8')

strings = app/'src/main/res/values/strings.xml'
s = strings.read_text(encoding='utf-8')
s,n = re.subn(r'<string name="app_name"([^>]*)>[^<]*</string>',
              r'<string name="app_name"\1>Zent Plus</string>',s,count=1)
if n != 1: raise SystemExit('app_name string not found')
strings.write_text(s,encoding='utf-8')

# Preserve the existing Xray service; disable exported developer extras.
xml = manifest.read_text(encoding='utf-8')
for kind, name in (('activity','.ui.UrlSchemeActivity'),('activity','.ui.shortcut.TaskerActivity'),
                   ('receiver','.receiver.TaskerReceiver')):
    regex = re.compile(r'(<'+kind+r'\b[^>]*?android:name="'+re.escape(name)+r'"[^>]*?android:exported=")true("[^>]*>)',re.S)
    xml, n = regex.subn(r'\1false\2',xml,count=1)
    if n != 1: raise SystemExit('Expected component missing: '+name)
for kind, name in (('service','.service.QSTileService'), ('receiver','.receiver.WidgetProvider'),
                   ('receiver','.receiver.BootReceiver')):
    regex = re.compile(r'(<'+kind+r'\b[^>]*?android:name="'+re.escape(name)+r'"\s*)',re.S)
    xml,n = regex.subn(r'\1android:enabled="false"\n        ',xml,count=1)
    if n != 1: raise SystemExit('Expected component missing: '+name)

assets = root/'zent/assets'
res = app/'src/main/res'
for file in assets.rglob('*'):
    if file.is_file():
        dst = res/file.relative_to(assets)
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(file,dst)
appmatch = re.search(r'<application\b[^>]*>',xml,re.S)
if not appmatch: raise SystemExit('Manifest application tag missing')
header = appmatch.group(0)
if 'android:icon="@mipmap/ic_launcher"' not in header:
    raise SystemExit('Manifest launcher icon mismatch')
header = header.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/zent_launcher"', 1)
if 'android:roundIcon=' in header:
    header = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/zent_launcher"',header,count=1)
else:
    header = header.replace('<application', '<application android:roundIcon="@mipmap/zent_launcher"', 1)
xml=xml[:appmatch.start()] + header + xml[appmatch.end():]
manifest.write_text(xml,encoding='utf-8')

build = gradle.read_text(encoding='utf-8')
old_id = 'applicationId = "com.mrsand2002.sandeepavpn"'
if old_id not in build and 'applicationId = "com.zentplus.vpn"' not in build:
    raise SystemExit('Unexpected Android package ID')
build = build.replace(old_id, 'applicationId = "com.zentplus.vpn"',1)
if not re.search(r'versionCode\s*=\s*\d+',build): raise SystemExit('versionCode missing')
version_code = int(os.environ.get('ZENT_VERSION_CODE','763'))
if version_code < 763 or version_code > 2_000_000:
    raise SystemExit('Invalid ZENT_VERSION_CODE')
build = re.sub(r'versionCode\s*=\s*\d+', f'versionCode = {version_code}',build,count=1)
version_name = os.environ.get('ZENT_VERSION_NAME','2.2.0')
if not re.fullmatch(r'\d+\.\d+\.\d+',version_name): raise SystemExit('Invalid ZENT_VERSION_NAME')
build = re.sub(r'versionName\s*=\s*"[^"]+"', f'versionName = "{version_name}"',build,count=1)

# Stable keystore provided via GitHub Actions secrets; debug builds remain usable for testing.
if 'create("zentRelease")' not in build:
    needle = '    buildTypes {'
    if needle not in build: raise SystemExit('Gradle buildTypes anchor not found')
    snippet = '''    signingConfigs {
        if (!System.getenv("ZENT_KEYSTORE_FILE").isNullOrBlank()) {
            create("zentRelease") {
                storeFile = file(System.getenv("ZENT_KEYSTORE_FILE"))
                storePassword = System.getenv("ZENT_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ZENT_KEY_ALIAS")
                keyPassword = System.getenv("ZENT_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
'''
    build = build.replace(needle, snippet,1)
    # tie release variant to the stable key only when secret configured
    release_needle = '        release {'
    if release_needle not in build: raise SystemExit('Gradle release anchor not found')
    build = build.replace(release_needle,
        '        release {\n            if (!System.getenv("ZENT_KEYSTORE_FILE").isNullOrBlank()) {\n'
        '                signingConfig = signingConfigs.getByName("zentRelease")\n            }',1)
gradle.write_text(build,encoding='utf-8')
print('Zent Plus v2.2 overlay applied: package, customer UI, profile sync, app version, signed-release configuration.')
